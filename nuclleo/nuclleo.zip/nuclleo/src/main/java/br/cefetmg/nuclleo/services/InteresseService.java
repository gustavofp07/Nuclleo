package br.cefetmg.nuclleo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import br.cefetmg.nuclleo.dto.InteresseRequestDTO;
import br.cefetmg.nuclleo.dto.InteresseStatusDTO;
import br.cefetmg.nuclleo.dto.TransacaoRequestDTO;
import br.cefetmg.nuclleo.model.Anuncio;
import br.cefetmg.nuclleo.model.Avaliacao;
import br.cefetmg.nuclleo.exception.BusinessException;
import br.cefetmg.nuclleo.model.Interesse;
import br.cefetmg.nuclleo.model.Status;
import br.cefetmg.nuclleo.model.Transacao;
import br.cefetmg.nuclleo.model.Usuario;
import br.cefetmg.nuclleo.repository.AvaliacaoRepository;
import br.cefetmg.nuclleo.repository.InteresseRepository;
import br.cefetmg.nuclleo.repository.MensagemRepository;
import br.cefetmg.nuclleo.dto.AvaliarAnuncianteRequestDTO;
import br.cefetmg.nuclleo.dto.FinalizarConversaRequestDTO;
import br.cefetmg.nuclleo.dto.NotificacaoDTO;

import org.springframework.transaction.annotation.Transactional;

@Service
public class InteresseService {
    @Autowired
    private InteresseRepository interesseRepository;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private AnuncioService anuncioService;

    @Autowired
    private TransacaoService transacaoService;

    @Autowired
    private AvaliacaoService avaliacaoService;

    @Autowired
    private AvaliacaoRepository avaliacaoRepository;

    @Autowired
    private MensagemRepository mensagemRepository;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @Transactional
    public Interesse inserir(InteresseRequestDTO dto) {

        Usuario usuario = usuarioService.buscarPorId(dto.getCdUsuario());

        Anuncio anuncio = anuncioService.buscarPorId(dto.getCdAnuncio());

        // equals (e não ==): comparar Long com == só funciona para números pequenos
        if (usuario.getCdUsuario().equals(anuncio.getUsuarioCria().getCdUsuario())) {
            throw new IllegalArgumentException("O usuário não pode demonstrar interesse em seu próprio anúncio.");
        }

        // Não é possível demonstrar interesse em anúncio suspenso/excluído ou de dono indisponível
        if (anuncio.getStatus() != Status.ATIVO || anuncio.getUsuarioCria().getStatus() != Status.ATIVO) {
            throw new BusinessException("Este anúncio não está disponível no momento.");
        }

        if (!usuario.isAtivo()) {
            throw new BusinessException("Sua conta não está ativa.");
        }

        Interesse interesse = new Interesse();
        interesse.setUsuario(usuario);
        interesse.setAnuncio(anuncio);
        interesse.setData(new java.sql.Date(System.currentTimeMillis()));

        return interesseRepository.save(interesse);
    }

    @Transactional
    public void finalizarConversa(Long idInteresse, Long cdUsuarioSolicitante, FinalizarConversaRequestDTO dto) {
        Interesse interesse = buscarPorId(idInteresse);

        Usuario anunciante = interesse.getAnuncio().getUsuarioCria();
        Usuario interessado = interesse.getUsuario();

        if (!anunciante.getCdUsuario().equals(cdUsuarioSolicitante)) {
            throw new IllegalArgumentException("Apenas o anunciante pode finalizar a conversa.");
        }

        if (interesse.isFinalizado()) {
            throw new IllegalArgumentException("Esta conversa já foi finalizada.");
        }

        if (dto.isOcorreuTransacao()) {
            if (dto.getValor() == null || dto.getValor() <= 0) {
                throw new IllegalArgumentException("Informe um valor válido para a transação.");
            }

            TransacaoRequestDTO transacaoDto = new TransacaoRequestDTO();
            transacaoDto.setValor(dto.getValor());
            transacaoDto.setCdUsuario(interessado.getCdUsuario());
            transacaoDto.setCdAnuncio(interesse.getAnuncio().getCdAnuncio());

            Transacao transacao = transacaoService.inserir(transacaoDto);

            Avaliacao avaliacaoAnunciantePraInteressado = avaliacaoRepository
                    .findByTransacaoId(transacao.getId()).stream()
                    .filter(a -> a.getAvaliador().getCdUsuario().equals(anunciante.getCdUsuario()))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("Falha ao localizar avaliação gerada."));

            avaliacaoService.avaliar(avaliacaoAnunciantePraInteressado.getCdAvaliacao(), anunciante.getCdUsuario(),
                    dto.getNotaInteressado());
        } else {
            List<Avaliacao> par = avaliacaoService.criarAvaliacoesPendentes(interessado, anunciante);
            avaliacaoService.avaliar(par.get(1).getCdAvaliacao(), anunciante.getCdUsuario(), dto.getNotaInteressado());
        }

        interesse.setFinalizado(true);
        interesse.setAvaliacaoInteressadoFeita(true);
        interesseRepository.save(interesse);

        notificarStatus(interesse);
        excluirSeAmbosAvaliaram(interesse);
    }

    @Transactional
    public void avaliarAnunciante(Long idInteresse, Long cdUsuarioSolicitante, AvaliarAnuncianteRequestDTO dto) {
        Interesse interesse = buscarPorId(idInteresse);

        Usuario anunciante = interesse.getAnuncio().getUsuarioCria();
        Usuario interessado = interesse.getUsuario();

        if (!interessado.getCdUsuario().equals(cdUsuarioSolicitante)) {
            throw new IllegalArgumentException("Apenas o interessado pode avaliar o anunciante.");
        }

        if (!interesse.isFinalizado()) {
            throw new IllegalArgumentException("A conversa ainda não foi finalizada pelo anunciante.");
        }

        if (interesse.isAvaliacaoAnuncianteFeita()) {
            throw new IllegalArgumentException("Você já avaliou o anunciante.");
        }

        List<Avaliacao> pendentes = avaliacaoRepository
                .findByAvaliadorCdUsuarioAndAvaliadoCdUsuarioAndNotaIsNull(interessado.getCdUsuario(),
                        anunciante.getCdUsuario());

        if (pendentes.isEmpty()) {
            throw new RuntimeException("Nenhuma avaliação pendente encontrada.");
        }

        avaliacaoService.avaliar(pendentes.get(0).getCdAvaliacao(), interessado.getCdUsuario(), dto.getNota());

        interesse.setAvaliacaoAnuncianteFeita(true);
        interesseRepository.save(interesse);

        notificarStatus(interesse);
        excluirSeAmbosAvaliaram(interesse);
    }

    private void notificarStatus(Interesse interesse) {
        InteresseStatusDTO status = new InteresseStatusDTO(
                interesse.isFinalizado(),
                interesse.isAvaliacaoInteressadoFeita(),
                interesse.isAvaliacaoAnuncianteFeita(),
                interesse.isAceito(),
                interesse.isConversaIniciada());

        messagingTemplate.convertAndSend("/topic/chat/" + interesse.getId() + "/status", status);
    }

    @Transactional
    public void iniciarConversa(Long id, Long cdUsuarioSolicitante) {
        Interesse interesse = buscarPorId(id);

        if (!interesse.getUsuario().getCdUsuario().equals(cdUsuarioSolicitante)) {
            throw new IllegalArgumentException("Apenas o usuário interessado pode iniciar a conversa.");
        }

        if (interesse.isFinalizado()) {
            throw new IllegalArgumentException("Não é possível iniciar uma conversa em um interesse já finalizado.");
        }

        interesse.setConversaIniciada(true);
        interesseRepository.save(interesse);

        Usuario anunciante = interesse.getAnuncio().getUsuarioCria();
        NotificacaoDTO notificacao = new NotificacaoDTO(
                "SOLICITACAO_CONVERSA",
                "Você recebeu uma nova solicitação de conversa",
                interesse.getId());

        messagingTemplate.convertAndSend("/topic/notificacoes/" + anunciante.getCdUsuario(), notificacao);
    }

    @Transactional
    public void recusarConversa(Long id, Long cdUsuarioSolicitante) {
        Interesse interesse = buscarPorId(id);

        if (!interesse.getAnuncio().getUsuarioCria().getCdUsuario().equals(cdUsuarioSolicitante)) {
            throw new IllegalArgumentException("Apenas o anunciante pode recusar a conversa.");
        }

        interesse.setConversaIniciada(false);
        interesse.setAceito(false);
        interesseRepository.save(interesse);

        notificarStatus(interesse);
    }

    private void excluirSeAmbosAvaliaram(Interesse interesse) {
        if (interesse.isAvaliacaoInteressadoFeita() && interesse.isAvaliacaoAnuncianteFeita()) {
            mensagemRepository.deleteByInteresseId(interesse.getId());
            interesseRepository.delete(interesse);
        }
    }

    @Transactional
    public void aceitarInteresse(Long idInteresse, Long cdUsuarioSolicitante) {
        Interesse interesse = buscarPorId(idInteresse);

        Usuario anunciante = interesse.getAnuncio().getUsuarioCria();

        if (!anunciante.getCdUsuario().equals(cdUsuarioSolicitante)) {
            throw new IllegalArgumentException("Apenas o anunciante pode aceitar a solicitação de chat.");
        }

        if (interesse.isAceito()) {
            throw new IllegalArgumentException("Esta solicitação de chat já foi aceita.");
        }

        interesse.setAceito(true);
        interesseRepository.save(interesse);

        notificarStatus(interesse);
    }

    @Transactional
    public void excluir(Long id) {
        Interesse interesse = interesseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Interesse não encontrado. Id: " + id));
        mensagemRepository.deleteByInteresseId(interesse.getId());
        interesseRepository.delete(interesse);
    }

    @Transactional(readOnly = true)
    public Interesse buscarPorId(Long id) {
        return interesseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Interesse não encontrado. Id: " + id));
    }

    @Transactional(readOnly = true)
    public List<Interesse> listarPorUsuario(Long id) {
        return interesseRepository.findByUsuarioCdUsuario(id);
    }

    @Transactional(readOnly = true)
    public List<Interesse> listarPorAnuncio(Long id) {
        return interesseRepository.findByAnuncioCdAnuncio(id);
    }

    @Transactional(readOnly = true)
    public List<Interesse> listarPorInteressados(Long cdUsuario) {
        return interesseRepository.findByAnuncioUsuarioCriaCdUsuario(cdUsuario);
    }
}