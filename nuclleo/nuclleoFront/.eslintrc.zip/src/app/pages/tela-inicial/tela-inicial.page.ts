import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

import {
  IonContent,
  IonLabel,
  IonAvatar,
  IonItem,
  IonButton,
  IonCardSubtitle,
  IonCardTitle,
  IonCard,
  IonCardHeader,
  IonList,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonMenuButton,
  IonButtons,
  IonIcon,
  IonSpinner
} from '@ionic/angular/standalone';

import { Router } from '@angular/router';

import { UsuarioService } from 'src/app/services/usuario.service';

import { ToastController } from '@ionic/angular';

import { HttpClient } from '@angular/common/http';

import { AnuncioModel } from 'src/app/model/anuncio.model';
import { AnuncioService } from 'src/app/services/anuncio.service';
import { ComunidadeModel } from 'src/app/model/comunidade.model';
import { ComunidadeService } from 'src/app/services/comunidade.service';

@Component({
  selector: 'app-tela-inicial',
  templateUrl: './tela-inicial.page.html',
  styleUrls: ['./tela-inicial.page.scss'],
  standalone: true,

  imports: [
    IonContent,
    IonLabel,
    IonAvatar,
    IonItem,
    IonCardSubtitle,
    IonCardTitle,
    IonCard,
    IonCardHeader,
    IonList,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonMenuButton,
    IonButtons,
    CommonModule,
    FormsModule,
    IonButton,
    RouterLink,
    IonIcon,
    IonSpinner
  ]
})

export class TelaInicialPage implements OnInit {

  comunidades: ComunidadeModel[] = [];

  anunciosRecomendados: AnuncioModel[] = [];

  carregandoAnuncios: boolean = true;
  carregandoComunidades: boolean = true;

  constructor(
    private usuarioService: UsuarioService,
    private comunidadeService: ComunidadeService,
    private router: Router,
    private toastController: ToastController,
    private http: HttpClient,
    private anuncioService: AnuncioService,
  ) { }

  ngOnInit() {
    let aux = this.usuarioService.verificarSessao();

    if (aux == false) {
      this.exibirMensagem("Não há usuário logado.");
      this.router.navigate(['/login']);
      return;
    }

    this.carregarComunidades();
    this.carregarAnunciosRecomendados();
  }

  onErroImagem(anuncio: any) {
    anuncio.ftAnuncio = null;
  }

  ionViewWillEnter() {
    let aux = this.usuarioService.verificarSessao();

    if (aux == false) {
      this.exibirMensagem("Não há usuário logado.");
      this.router.navigate(['/login']);
      return;
    }

    this.carregarComunidades();
    this.carregarAnunciosRecomendados();
  }

  carregarComunidades() {
    const usuario = this.usuarioService.getUsuarioSessao();

    if (!usuario || !usuario.cdUsuario) {
      return;
    }

    this.carregandoComunidades = true;

    this.comunidadeService.listarComunidadesProximas(usuario.cdUsuario).subscribe({
      next: (comunidades: ComunidadeModel[]) => {
        this.comunidades = comunidades;
        this.carregandoComunidades = false;
      },
      error: (erro: any) => {
        console.error('Erro ao carregar comunidades próximas:', erro);
        this.carregandoComunidades = false;
      }
    });
  }

  carregarAnunciosRecomendados() {
    this.carregandoAnuncios = true;

    this.anuncioService.listarTodos().subscribe({
      next: (dados) => {
        this.anunciosRecomendados = dados
          .sort(() => Math.random() - 0.5)
          .slice(0, 5);
        this.carregandoAnuncios = false;
      },
      error: () => {
        console.log('Erro ao carregar anúncios recomendados.');
        this.carregandoAnuncios = false;
      }
    });
  }

  async exibirMensagem(texto: string) {
    const toast =
      await this.toastController.create({
        message: texto,
        duration: 2000
      });
    toast.present();
  }

}