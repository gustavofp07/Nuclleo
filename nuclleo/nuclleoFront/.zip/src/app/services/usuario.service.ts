import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UsuarioModel } from '../model/usuario.model';
import { Observable } from 'rxjs';
import { UsuarioAutenticadoModel } from '../model/usuario-autenticado.model';

@Injectable({
  providedIn: 'root',
})
export class UsuarioService {
  private readonly KEY_USUARIO = 'usuarioAutenticado';
  private readonly API_URL = 'https://nuclleo.onrender.com/api/v1/usuarios';
  private readonly AUTH_URL = 'https://nuclleo.onrender.com/api/v1/autenticar';

  autenticar(credenciais: { email: string; senha: string }): Observable<any> {
    return this.http.post<any>(this.AUTH_URL, credenciais);
  }
  constructor(private http: HttpClient) { }

  cadastrarUsuario(usuario: UsuarioModel): Observable<UsuarioModel> {//body
    return this.http.post<UsuarioModel>(this.API_URL, usuario);
  }

  excluirUsuario(cdUsuario: number): Observable<UsuarioModel> {
    return this.http.delete<UsuarioModel>(`${this.API_URL}/${cdUsuario}`);
  }

  buscarUsuario(cdUsuario: number): Observable<UsuarioModel> {//varivel
    return this.http.get<UsuarioModel>(`${this.API_URL}/${cdUsuario}`);
  }

  atualizar(usuario: UsuarioModel): Observable<UsuarioModel> {//body
    return this.http.put<UsuarioModel>(this.API_URL, usuario);
  }


  //coisas da sessão
  salvarUsuarioSessao(usuario: UsuarioAutenticadoModel): void {
    localStorage.setItem(this.KEY_USUARIO, JSON.stringify(usuario));
  }

  limparSessao(): void {
    localStorage.removeItem(this.KEY_USUARIO);
  }

  verificarSessao(): boolean {
    if (localStorage.getItem(this.KEY_USUARIO) !== null) {
      return true;
    } else {
      return false;
    }
  }

  getUsuarioSessao(): UsuarioModel {
    const usuarioJson = localStorage.getItem(this.KEY_USUARIO);
    if (usuarioJson) {
      return JSON.parse(usuarioJson) as UsuarioModel;
    }
    return new UsuarioModel();
  }
}
