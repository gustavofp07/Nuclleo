import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Capacitor } from '@capacitor/core';

@Injectable({
  providedIn: 'root',
})
export class ArquivoService {

  constructor() { }

  public async capturar(): Promise<File | undefined> {

    // Se estiver rodando no navegador, usa input file nativo
    if (!Capacitor.isNativePlatform()) {
      return this.capturarViaInput();
    }

    // Se estiver no dispositivo, usa a câmera do Capacitor
    try {
      const camera = await Camera.getPhoto({
        resultType: CameraResultType.Uri,
        source: CameraSource.Prompt,
        quality: 50,
        saveToGallery: true,
        promptLabelHeader: 'Foto',
        promptLabelPhoto: 'Galeria',
        promptLabelPicture: 'Câmera',
        promptLabelCancel: 'Cancelar'
      });

      if (!camera.webPath) {
        return;
      }

      const response = await fetch(camera.webPath);
      const blob = await response.blob();

      const extensao = camera.format || 'jpeg';
      const nomeArquivo = `foto-${Date.now()}.${extensao}`;

      return new File([blob], nomeArquivo, { type: blob.type });

    } catch (erro) {
      console.log('Captura cancelada ou não concluída.');
      return;
    }
  }

  private capturarViaInput(): Promise<File | undefined> {
    return new Promise((resolve) => {

      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/jpeg, image/png';

      input.onchange = (event: any) => {
        const arquivo = event.target.files?.[0];
        resolve(arquivo ?? undefined);
      };

      input.oncancel = () => resolve(undefined);

      input.click();
    });
  }
}
