import{a as i}from"./chunk-EUUR52VS.js";var o=class{constructor(){this.cdAnuncio=0,this.nmAnuncio="",this.descricao="",this.tipoAnuncio="",this.usuarioCria=new i}};export{o as a};
