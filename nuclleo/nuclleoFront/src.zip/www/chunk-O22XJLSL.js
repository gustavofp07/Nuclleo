import{a as i}from"./chunk-MDDQFLTU.js";var o=class{constructor(){this.cdComunidade=0,this.descricao="",this.nmComunidade="",this.usuarioCria=new i,this.foto=""}};export{o as a};
