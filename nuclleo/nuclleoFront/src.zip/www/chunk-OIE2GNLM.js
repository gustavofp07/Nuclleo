import{a as i}from"./chunk-MDDQFLTU.js";var t=class{constructor(){this.cdAnuncio=0,this.nmAnuncio="",this.descricao="",this.tipoAnuncio="",this.habilitado=!0,this.usuarioCria=new i}};export{t as a};
